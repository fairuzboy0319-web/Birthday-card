BATRISYIA BIRTHDAY CARD
========================

Open index.html to preview the card.

Included:
- 2 photos
- 2 memory videos
- music.mp4 (the uploaded video containing the selected background song)
- index.html

IMPORTANT:
For the final QR to work on another phone, this folder must be published to a public web host.
The recommended route is Netlify. Once the site is deployed and a public URL exists, a QR can encode that exact URL.
